export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyDlRp7v2Uvu-E8O_E0IDYdC3CoJh9cbNsc',
    authDomain: 'chat-4f314.firebaseapp.com',
    databaseURL: 'https://chat-4f314.firebaseio.com',
    projectId: 'chat-4f314',
    storageBucket: 'chat-4f314.appspot.com',
    messagingSenderId: '818262862528'
  }
};
