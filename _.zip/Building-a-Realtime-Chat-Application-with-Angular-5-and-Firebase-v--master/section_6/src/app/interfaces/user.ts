export interface User {
  id: string;
  firstName: string;
  lastName: string;
  photoUrl: string;
  email: string;
  quote: string;
  bio: string;
}
